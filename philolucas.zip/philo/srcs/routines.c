/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   routines.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lberthal <lberthal@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 06:41:34 by lberthal          #+#    #+#             */
/*   Updated: 2024/07/01 06:50:28 by lberthal         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philo.h"

void *routine(void *arg)
{
	t_philo *philo;

	philo = (t_philo *)arg;
	if (philo->id % 2 == 0)
		ft_usleep(100);
	while (1)
	{
		if (philo->a->stop)
			return (NULL);
		if (who_pick_the_fork(philo))
			return (NULL);
		philo->last_time_eat = current_time(philo->time_start);
		if (print_state(philo, 2))
			return (NULL);
		ft_usleep(philo->time_to_eat);
		release_forks(philo);
		if (print_state(philo, 3))
			return (NULL);
		ft_usleep(philo->time_to_sleep);
		if (print_state(philo, 0))
			return (NULL);
		if (philo->has_eat >= philo->nb_eat && philo->nb_eat != -1)
			return (NULL);
	}
	return (NULL);
}

int print_state(t_philo *philo, int state)
{
	int time = current_time(philo->a->time_start);
	(void)time;
	if (state == 0)
	{
		if (check_death(philo->a) || check_eat(philo->a))
			return (1);
		pthread_mutex_lock(philo->a->print);
		printf("%ld %d is thinking\n", gt() - philo->a->time_start, philo->id);
		pthread_mutex_unlock(philo->a->print);
	}
	else if (state == 1)
	{
		if (check_death(philo->a) || check_eat(philo->a))
			return (1);
		pthread_mutex_lock(philo->a->print);
		printf("%ld %d has taken a fork\n", gt() - philo->a->time_start, philo->id);
		pthread_mutex_unlock(philo->a->print);
	}
	else if (state == 2)
	{
		if (check_death(philo->a) || check_eat(philo->a))
			return (1);
		pthread_mutex_lock(philo->a->print);
		printf("%ld %d is eating\n", gt() - philo->a->time_start, philo->id);
		pthread_mutex_unlock(philo->a->print);
	}
	else if (state == 3)
	{
		if (check_death(philo->a) || check_eat(philo->a))
			return (1);
		pthread_mutex_lock(philo->a->print);
		printf("%ld %d is sleeping\n", gt() - philo->a->time_start, philo->id);
		pthread_mutex_unlock(philo->a->print);
	}
	else if (state == 4)
	{
		if (check_death(philo->a) || check_eat(philo->a))
			return (1);
		pthread_mutex_lock(philo->a->print);
		printf("%ld %d died\n", gt() - philo->a->time_start, philo->id);
		pthread_mutex_unlock(philo->a->print);
	}
	return (0);
}
void *monitoring(void *arg)
{
	t_a *a;
	int i;

	a = (t_a *)arg;
	while (1)
	{
		i = 0;
		while (i < a->nb_philo)
		{
			if (a->nb_eat != -1 && check_eat(a))
				return (NULL);
			if (a->stop)
				return (NULL);
			if ((current_time(a->time_start) - a->philo[i]->last_time_eat) > (size_t)a->time_to_die)
			{
				print_state(a->philo[i], 4);
				a->stop = 1;
				pthread_mutex_lock(a->philo[i]->a->stop_m);
				a->philo[i]->stop = 1;
				pthread_mutex_unlock(a->philo[i]->a->stop_m);
				return (NULL);
			}
			i++;
		}
		if (a->stop)
			return (NULL);
	}
}

int who_pick_the_fork(t_philo *philo)
{
	if (check_death(philo->a) || check_eat(philo->a))
		return (1);
	take_forks(philo);
	pthread_mutex_lock(philo->a->eat);
	philo->has_eat++;
	pthread_mutex_unlock(philo->a->eat);
	return (0);
}

int check_death(t_a *a)
{
	int stop;

	pthread_mutex_lock(a->stop_m);
	stop = a->stop;
	pthread_mutex_unlock(a->stop_m);
	if (stop == 1)
		return (1);
	else
		return (0);
	return (0);
}

int check_eat(t_a *a)
{
	int i;
	int count;

	i = 0;
	count = 0;
	while (i < a->nb_philo && a->nb_eat != -1)
	{
		if (a->philo[i]->has_eat >= a->nb_eat)
			count++;
		i++;
	}
	if (count == a->nb_philo && a->nb_eat != -1)
	{
		a->stop = 1;
		return (1);
	}
	return (0);
}

void    take_forks(t_philo *philo)
{
	if (philo->id % 2 == 0)
	{
		pthread_mutex_lock(philo->right);
		print_state(philo, 1);
		philo->has_right = 1;
		pthread_mutex_lock(philo->left);
		print_state(philo, 1);
		philo->has_left = 1;
	}
	else if (philo->id % 2 != 0)
	{
		pthread_mutex_lock(philo->left);
		print_state(philo, 1);
		philo->has_left = 1;
		pthread_mutex_lock(philo->right);
		print_state(philo, 1);
		philo->has_right = 1;
	}
}

void    release_forks(t_philo *philo)
{
	if (philo->has_left)
	{
		pthread_mutex_unlock(philo->left);
		philo->has_left = 0;
	}
	if (philo->has_right)
	{
		pthread_mutex_unlock(philo->right);
		philo->has_right = 0;
	}
}
