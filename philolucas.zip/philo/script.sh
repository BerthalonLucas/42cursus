#! /bin/bash

for i in {1..100}
do
./philo 5 800 200 200 7 >> result.txt
done
grep -c "died" result.txt
