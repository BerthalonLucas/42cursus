#!/bin/bash

for i in {1..100}
do
    ./philo 4 800 200 200 2
done
